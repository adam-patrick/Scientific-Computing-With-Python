from distutils.core import setup

setup(
        name           = 'nester',
        version        = '1.0.0',
        py_module      = ['nester'],
        author         = 'adamjohnny5',
        authoremail    = 'adamjohnny5@gmail.com',
        url            = 'http://headfirstlabs.com',
        description    = 'A simple printer of nested lists',
     )
     
